<?php
// +----------------------------------------------------------------------
// | 海豚PHP框架 [ DolphinPHP ]
// +----------------------------------------------------------------------
// | 版权所有 2016~2017 河源市卓锐科技有限公司 [ http://www.zrthink.com ]
// +----------------------------------------------------------------------
// | 官方网站: http://dolphinphp.com
// +----------------------------------------------------------------------
// | 开源协议 ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------

return [
    // 产品信息
    'product_name'      => 'DolphinPHP',
    'product_version'   => '1.3.1',
    'build_version'     => '201809181126',
    'product_website'   => 'http://www.dolphinphp.com',
    'product_update'    => 'http://www.dolphinphp.com/checkUpdate',
    'develop_team'      => 'DolphinPHP',

    // 公司信息
    'company_name'    => '河源市卓锐科技有限公司',
    'company_website' => 'http://www.zrthink.com',
];