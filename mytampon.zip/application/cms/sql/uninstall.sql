-- -----------------------------
-- 导出时间 `2016-12-13 22:26:46`
-- -----------------------------
DROP TABLE IF EXISTS `dp_cms_advert`;
DROP TABLE IF EXISTS `dp_cms_advert_type`;
DROP TABLE IF EXISTS `dp_cms_column`;
DROP TABLE IF EXISTS `dp_cms_document`;
DROP TABLE IF EXISTS `dp_cms_field`;
DROP TABLE IF EXISTS `dp_cms_link`;
DROP TABLE IF EXISTS `dp_cms_menu`;
DROP TABLE IF EXISTS `dp_cms_model`;
DROP TABLE IF EXISTS `dp_cms_nav`;
DROP TABLE IF EXISTS `dp_cms_page`;
DROP TABLE IF EXISTS `dp_cms_slider`;
DROP TABLE IF EXISTS `dp_cms_support`;
