<?php
namespace app\customer\admin;

use app\admin\controller\Admin;

class Index extends Admin
{

}