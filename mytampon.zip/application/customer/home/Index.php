<?php
namespace app\customer\home;

use app\index\controller\Home;

class Index extends Home
{
    
}